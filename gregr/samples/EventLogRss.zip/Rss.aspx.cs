using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;

namespace EventLogRss
{
	/// <summary>
	/// Summary description for Rss.
	/// </summary>
	public class Rss : System.Web.UI.Page
	{
		private int NUM_ENTRIES = 100;

		private void Page_Load(object sender, System.EventArgs e)
		{
			object o = Request.QueryString["num"];
			if (o != null)
				NUM_ENTRIES = Int32.Parse((string)o);

			string[] logs = new String[] {"System", "Application"};

			o = Request.QueryString["logs"];
			if (o != null)
			{
				logs = o.ToString().Split(new char[] {','});
			}

			ArrayList entries = GetCombinedLogEntries(logs);
			RenderRss(entries, Response.OutputStream);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion

		private ArrayList GetCombinedLogEntries(string[] logNames)
		{
			ArrayList combined = new ArrayList();
			foreach (string logName in logNames)
			{
				LogEntry[] entries = GetLogEntries(logName);
				combined.AddRange(entries);
			}
			combined.Sort(new Sorter());
			return combined;
		}

		private LogEntry[] GetLogEntries(string logName)
		{
			int numEntries = NUM_ENTRIES;

			EventLog log = new EventLog(logName);
			EventLogEntryCollection logEntries = log.Entries;
			int count = logEntries.Count;
			if (count < numEntries)
				numEntries = count;

			LogEntry[] entries = new LogEntry[numEntries];

			for (int i = 0 ; i < numEntries ; i++)
				entries[i] = new LogEntry(logName, logEntries[count - i - 1]);

			return entries;
		}

		public void RenderRss(ArrayList entries, Stream s)
		{
			DateTime mostRecent = ((LogEntry)entries[0]).Entry.TimeGenerated;
			string modifiedDate = mostRecent.ToString("r");

			XmlTextWriter w = new XmlTextWriter(s, null);
			
			w.WriteStartElement("rss");
			w.WriteAttributeString("version", "2.0");
			w.WriteAttributeString("xmlns", "dc", null, "http://purl.org/dc/elements/1.1/");

			w.WriteStartElement("channel");
			w.WriteElementString("title","Event Log Monitor");
			w.WriteElementString("link","http://www.rassoc.com/gregr/weblog");
			w.WriteElementString("description","Event Log Monitor");
			w.WriteElementString("copyright","Copyright (c) 2003 Greg Reinacker, Reinacker & Associates, Inc.");
			w.WriteElementString("managingEditor","gregr@rassoc.com");
			w.WriteElementString("webMaster","gregr@rassoc.com");
			w.WriteElementString("lastBuildDate", modifiedDate);
			w.WriteElementString("ttl", "60");

			int numEntries = NUM_ENTRIES;
			if (entries.Count < numEntries)
				numEntries = entries.Count;

			for (int i = 0 ; i < numEntries ; i++)
			{
				LogEntry entry = (LogEntry)entries[i];

				string category = "";
				if (entry.Entry.CategoryNumber != 0)
					category = entry.Entry.Category;

				w.WriteStartElement("item");
				w.WriteElementString("title", entry.Entry.EntryType.ToString() + ": " + entry.Entry.Source);
				w.WriteElementString("link", "http://example.org/viewlog.aspx?n=" + Server.UrlEncode(entry.LogName) + "&i=" + entry.Entry.Index);
				w.WriteStartElement("guid");
				w.WriteAttributeString("isPermaLink","false");
				w.WriteString(entry.LogName + ":" + entry.Entry.Index);
				w.WriteEndElement();
				w.WriteElementString("description", entry.Entry.Message);
				w.WriteElementString("pubDate", entry.Entry.TimeGenerated.ToString("r"));
				if (category.Length > 0)
					w.WriteElementString("category", category);
				w.WriteElementString("creator", "http://purl.org/dc/elements/1.1/", entry.LogName);
				w.WriteEndElement(); // item
			}

			w.WriteEndElement(); // channel
			w.WriteEndElement(); // rss

			w.Flush();
		}
	
	}

	class Sorter : IComparer
	{
		public Sorter()
		{
		}

		public int Compare(object x, object y)
		{
			LogEntry e1 = (LogEntry)x;
			LogEntry e2 = (LogEntry)y;
			return e2.Entry.TimeGenerated.CompareTo(e1.Entry.TimeGenerated);
		}
	}

	class LogEntry
	{
		public LogEntry(string logName, EventLogEntry entry)
		{
			LogName = logName;
			Entry = entry;
		}

		public string LogName;
		public EventLogEntry Entry;
	}
}
