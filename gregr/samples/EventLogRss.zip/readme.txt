Windows event log to RSS converter
==================================

Written by Greg Reinacker
http://www.rassoc.com/gregr/weblog/


Read these feeds with NewsGator! 
http://www.newsgator.com

----------------------------------

INSTRUCTIONS:

Add the Rss.aspx and Rss.aspx.cs files into an ASP.NET 
project, and compile.  You will need to modify some of 
the specific URL's pointing to Greg Reinacker's weblog,
but other than that it should be ready to go.


USAGE:

The URL to use to request the feed has optional parameters
to define how many entries and which logs will be used.
Examples:


http://myserver.com/Rss.aspx

Returns 100 most recent entries, chosen from the System and 
Application logs.


http://myserver.com/Rss.aspx?num=50

Returns 50 most recent entries, chosen from the System and 
Application logs.


http://myserver.com/Rss.aspx?num=20&logs=Application

Returns 20 most recent entries from the Application log.


http://myserver.com/Rss.aspx?num=20&logs=System,Application

Returns 20 most recent entries, chosen from the System and 
Application logs.
