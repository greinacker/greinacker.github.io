using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Xml;

namespace VssRssSvc
{
	/// <summary>
	/// Summary description for GenRss.
	/// </summary>
	public class GenRss
	{
		ServiceBase svc = null;

		public GenRss(ServiceBase svc)
		{
			this.svc = svc;
		}

		public void Go()
		{
			//svc.EventLog.WriteEntry("RSS generation starting", EventLogEntryType.Information);

			try
			{
				string assemblyFile = Assembly.GetExecutingAssembly().Location;
				string assemblyDir = Path.GetDirectoryName(assemblyFile);
				if (!assemblyDir.EndsWith("\\"))
					assemblyDir += "\\";
				string configPath = assemblyDir + "config.xml";

				XmlDocument doc = new XmlDocument();
				doc.Load(configPath);
				XmlNodeList nodes = doc.SelectNodes("/VssRss/project");
				foreach (XmlNode node in nodes)
				{
					string srcSafeIniPath = node.SelectSingleNode("SourceSafePath").InnerText;
					string vssUser = node.SelectSingleNode("SourceSafeUser").InnerText;
					string vssPass = node.SelectSingleNode("SourceSafePassword").InnerText;
					string project = node.SelectSingleNode("SourceSafeProject").InnerText;
					string outputPath = node.SelectSingleNode("OutputPath").InnerText;
					int maxItems = Int32.Parse(node.SelectSingleNode("MaxItems").InnerText);
					bool recursive = Boolean.Parse(node.SelectSingleNode("Recursive").InnerText);
					BuildRss(srcSafeIniPath, vssUser, vssPass, project, outputPath, maxItems, recursive);
				}
			}
			catch (Exception ex)
			{
				svc.EventLog.WriteEntry("Exception occurred: " + ex.Message + " " + ex.StackTrace, EventLogEntryType.Error);
			}

			//svc.EventLog.WriteEntry("RSS generation complete", EventLogEntryType.Information);
		}

		protected void BuildRss(string srcSafeIniPath, string vssUser, string vssPass, string projectName, string outputPath, int maxItems, bool recursive)
		{
			SourceSafeTypeLib.VSSDatabase db = null;
			SourceSafeTypeLib.VSSItem item = null;
			SourceSafeTypeLib.IVSSVersions versions = null;

			try
			{
				StringWriter sw = new StringWriter();
				//XmlTextWriter w = new XmlTextWriter(outputPath, System.Text.Encoding.ASCII);
				XmlTextWriter w = new XmlTextWriter(sw);
				db = new SourceSafeTypeLib.VSSDatabaseClass();
				db.Open(srcSafeIniPath, vssUser, vssPass);
			
				w.WriteStartElement("rss");
				w.WriteAttributeString("version", "2.0");
				w.WriteAttributeString("xmlns", "dc", null, "http://purl.org/dc/elements/1.1/");

				w.WriteStartElement("channel");
				w.WriteElementString("title","VSS Monitor: " + projectName);
				w.WriteElementString("link","http://www.newsgator.com");
				w.WriteElementString("description","Visual SourceSafe Monitor");
				w.WriteElementString("copyright","Copyright (c) 2003-2004 NewsGator Technologies, Inc.");
				w.WriteElementString("managingEditor","me@example.org");
				w.WriteElementString("webMaster","me@example.org");
				w.WriteElementString("lastBuildDate", DateTime.Now.ToUniversalTime().ToString("r"));
				w.WriteElementString("ttl", "60");


				item = db.get_VSSItem(projectName,false);

				int i = 0;
				versions = item.get_Versions(recursive ? 8192 : 0);
				foreach (SourceSafeTypeLib.IVSSVersion ver in versions)
				{
					i++;
					if (i > maxItems)
						continue;

					string action = ver.Action;
					string file = ver.VSSItem.Name;
					string user = ver.Username;
					string vernum = ver.VersionNumber.ToString();
					string comment = ver.Comment;
				
					DateTime dt = ver.Date;

					w.WriteStartElement("item");
					w.WriteElementString("title", String.Format("{0}/{1}", action, file));
					w.WriteStartElement("guid");
					w.WriteAttributeString("isPermaLink","false");
					w.WriteString(String.Format("{0}:{1}:{2}", file, vernum, action));
					w.WriteEndElement();
					w.WriteElementString("description", String.Format("{0}",comment));
					w.WriteElementString("pubDate", dt.ToUniversalTime().ToString("r"));
					w.WriteElementString("creator", "http://purl.org/dc/elements/1.1/", user);
					w.WriteEndElement(); // item

					Marshal.ReleaseComObject(ver);
				}


				w.WriteEndElement(); // channel
				w.WriteEndElement(); // rss

				w.Flush();

				sw.Flush();
			
				StreamWriter writer = new StreamWriter(outputPath, false);
				writer.Write(sw.ToString());
				writer.Flush();
				writer.Close();

				sw.Close();
			}
			catch (Exception ex)
			{
				string msg = String.Format("Exception occurred generating RSS.\r\nVSS Database: {0}\r\nVSS Project: {1}\r\nException:\r\n{2}",
					srcSafeIniPath, projectName, ex.Message + "\r\n" + ex.StackTrace);
				svc.EventLog.WriteEntry(msg, EventLogEntryType.Error);
			}
			finally
			{
				if (versions != null)
					Marshal.ReleaseComObject(versions);

				if (item != null)
					Marshal.ReleaseComObject(item);

				if (db != null)
					Marshal.ReleaseComObject(db);
			}
		}

	}
}
