using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.ServiceProcess;
using System.Timers;
using System.Xml;

namespace VssRssSvc
{
	public class Service1 : System.ServiceProcess.ServiceBase
	{
		private System.Timers.Timer timer1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Service1()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitComponent call
		}

		// The main entry point for the process
		static void Main()
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			// More than one user Service may run within the same process. To add
			// another service to this process, change the following line to
			// create a second service object. For example,
			//
			//   ServicesToRun = New System.ServiceProcess.ServiceBase[] {new Service1(), new MySecondUserService()};
			//
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new Service1() };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);
		}

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.timer1 = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
			// 
			// Service1
			// 
			this.ServiceName = "VSS RSS Generator";
			((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
//			DateTime dt = new DateTime(2004,10,31);
//			if (DateTime.Now > dt)
//			{
//				EventLog.WriteEntry("VSS RSS generator service has expired; please visit http://www.rassoc.com/gregr/weblog for an updated version.", EventLogEntryType.Error);
//				throw new ApplicationException("Expired");
//			}

			try
			{
				string assemblyFile = Assembly.GetExecutingAssembly().Location;
				string assemblyDir = Path.GetDirectoryName(assemblyFile);
				if (!assemblyDir.EndsWith("\\"))
					assemblyDir += "\\";
				string configPath = assemblyDir + "config.xml";

				XmlDocument doc = new XmlDocument();
				doc.Load(configPath);
				int interval = Int32.Parse(doc.DocumentElement.SelectSingleNode("Interval").InnerText);
				interval = interval * 60000;

				timer1.Interval = interval;
				timer1.Elapsed += new ElapsedEventHandler(this.OnTimer);
				timer1.Enabled = true;
			}
			catch (Exception ex)
			{
				EventLog.WriteEntry("Failed to initialize VSS RSS service: " + ex.Message, EventLogEntryType.Error);
				throw;
			}

			TimerDelegate td = new TimerDelegate(OnTimer);
			td.BeginInvoke(null, null, null, null);
		}
 
		internal delegate void TimerDelegate(object source, ElapsedEventArgs e);

		protected void OnTimer(object source, ElapsedEventArgs e)
		{
			if (!inProgess)
			{
				inProgess = true;
				GenRss rss = new GenRss(this);
				rss.Go();
				inProgess = false;
			}
		}

		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			// TODO: Add code here to perform any tear-down necessary to stop your service.
		}

		private volatile bool inProgess = false;
	}
}
